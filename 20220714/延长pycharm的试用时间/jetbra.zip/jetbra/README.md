# 操作指南
1. 为整个文件夹找个合适的位置（尽量不要放在桌面或者C盘根目录）
2. 在“许可证”窗口中注销 jb 帐户
3. 配置 vmoptions
    1. 自动（推荐）
        macOS 或 Linux：执行 `scripts/install.sh` 文件
        Windows：执行 `scripts\install-current-user.vbs` （对于当前用户）或者 `scripts\install-all-users.vbs`（适用于所有用户）
    2. 手动
        找到 *.vmoptions 文件并在文件内添加 `-javaagent:/path/to/ja-netfilter.jar=jetbrains`（绝对路径）
4. 使用页面上的密钥 https://jetbra.in/5d84466e31722979266057664941a71893322460
5. 插件 `mymap` 自 2022.1 版起已弃用
6. 不用关心激活时间，是 fallback license，不会过期

尽情享受吧~

# 其他的配置
JBR17：
     将这两行添加到您的 vmoptions 文件中：（对于手动，没有任何空白字符）
     --add-opens=java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED
     --add-opens=java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED

# 参考
https://zhile.io/
https://gitee.com/ja-netfilter/ja-netfilter
https://gitee.com/ja-netfilter/ja-netfilter-sample-plugin